<header class="header-main-wraper inner-siteheader-wraper">

    <?php $this->load->view('common/header') ?>

        <!--inner page heading-->
        <div class="inner-page-heading">
            <div class="container w3-animate-left">
                <div class="row">

                    <div class="col-md-8 col-sm-8 col-xs-12 ">
                        <h1>  Ma<span>ps</span>  </h1>
                        <p><?= $getsettingData['maps_page'] ?> </p>
                    </div>

                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="breadcrumsite">
                            <a href="#"> Home  </a><i class="fa fa-angle-right" aria-hidden="true"></i>
                            <a href="#"> Maps </a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!--inner page heading-->

</header>
<!-- //header ends-->

<!--content started-->
<div class="site-innercontent-wraper">

    <div class="maps-listingmain-wraper">
        <div class="container">
            <ul class="row">

                <li class="col-md-4 col-sm-6 col-xs-12">
                    <div class="maps-listing-wraper">
                        <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url()?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>

 </a>
                    </div>
                </li>

                <li class="col-md-4 col-sm-6 col-xs-12">
                    <div class="maps-listing-wraper">
                        <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url()?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>

 </a>
                    </div>
                </li>

                <li class="col-md-4 col-sm-6 col-xs-12">
                    <div class="maps-listing-wraper">
                        <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url()?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>

 </a>
                    </div>
                </li>

                <li class="col-md-4 col-sm-6 col-xs-12">
                    <div class="maps-listing-wraper">
                        <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url()?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>

 </a>
                    </div>
                </li>

                <li class="col-md-4 col-sm-6 col-xs-12">
                    <div class="maps-listing-wraper">
                        <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url()?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>

 </a>
                    </div>
                </li>

                <li class="col-md-4 col-sm-6 col-xs-12">
                    <div class="maps-listing-wraper">
                        <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url()?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>

 </a>
                    </div>
                </li>

                <li class="col-md-4 col-sm-6 col-xs-12">
                    <div class="maps-listing-wraper">
                        <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url()?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>

 </a>
                    </div>
                </li>

                <li class="col-md-4 col-sm-6 col-xs-12">
                    <div class="maps-listing-wraper">
                        <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url()?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>

 </a>
                    </div>
                </li>

                <li class="col-md-4 col-sm-6 col-xs-12">
                    <div class="maps-listing-wraper">
                        <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url()?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>

 </a>
                    </div>
                </li>

            </ul>
        </div>
    </div>

</div>
<!--//content ends-->