<header class="header-main-wraper inner-siteheader-wraper">

    <?php $this->load->view('common/header') ?>

        <!--inner page heading-->
        <div class="inner-page-heading">
            <div class="container w3-animate-left">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-12 ">
                        <h1> Blog <span>Listing</span> </h1>
                        <p><?= $getsettingData['blog_page2'] ?></p>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="breadcrumsite"> <a href="#"> Home </a><i class="fa fa-angle-right" aria-hidden="true"></i> <a href="#"> Blog Listing </a> </div>
                    </div>
                </div>
            </div>
        </div>
        <!--inner page heading-->

</header>
<!-- //header ends-->

<!--content started-->
<div class="blog-innercontent-wraper">

    <div class="blog-listingmain-wraper">
        <div class="container">
            <ul class="row">

                <div class="col-md-8">
                    <div class="blog-detail-wraper" data-aos="slide-up">

                        <div class="blog-detail-inner-wraper">
                            <div class="blog-listingmain-images" style="background:url(<?= base_url('../admin/assets/images/uploads/').$blogs->image?>) no-repeat top">
                                <a href="#"> </a>
                            </div>

                            <div class="inner-blogtext-detail-wraper">

                                <div class="blog-inner-date"> August 2019 </div>
                                <h2> <?= $blogs->title ?> </h2>
                                <p>
                                    <?= $blogs->description ?>
                                </p>

                            </div>

                        </div>

                    </div>
                </div>

                <div class="col-md-4">

                    <div class="search-listing-blog">
                        <h4> Search </h4>

                        <form>

                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Search">
                                <button> <i class="fa fa-search" aria-hidden="true"></i> </button>
                            </div>

                        </form>

                    </div>

                    <div class="category-main-wraper">
                        <h4> Categories </h4>

                        <a href="#"> For Sale </a>
                        <a href="#"> Rental </a>
                        <a href="#"> Uncategorized </a>

                    </div>

                    <div class="blog-contact-wraper">
                        <h4> Got Any Question? </h4>
                        <p> If you have any questions
                            <br>feel free to ask </p>
                        <a href="#"> Contact us </a>

                    </div>

                </div>

            </ul>
        </div>
    </div>

</div>
<!--//content ends-->