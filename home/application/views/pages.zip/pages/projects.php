


<!-- header started-->
<header class="header-main-wraper inner-siteheader-wraper"> 
  
  <!--header-->
  <?php $this->load->view('common/header') ?>
    
    
  
  <!--inner page heading-->
  <div class="inner-page-heading">
    <div class="container w3-animate-left">
      <div class="row">
        <div class="col-md-8 col-sm-8 col-xs-12 ">
          <h1> Pro<span>ject </span> </h1>
          <p><?= $getsettingData['project_page'] ?></p>
        </div>
        <div class="col-md-4 col-sm-4 col-xs-12">
          <div class="breadcrumsite"> <a href="#"> Home </a><i class="fa fa-angle-right" aria-hidden="true"></i> <a href="#"> Projects </a> </div>
        </div>
      </div>
    </div>
  </div>
  <!--inner page heading--> 
  
</header>
<!-- //header ends--> 

<!--content started-->
<div class="site-innercontent-wraper">
  <div class="about-main-wraper">
    <div class="about-texttop-wraper" data-aos="slide-up">
      <div class="container">
        <div class="row">
          <div class="col-md-5">
            <div class="about-text-wrp">
              <h3> Bahria Town Phase1 to 7 Islamabad Pakistan </h3>

              <p> Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia looked up one of the more obscure Latin words consectetur from a Lorem Ipsum passage nto electronic typesetting <br>
                <br>
                Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old </p>
              <div class="inner-service-detail-wraper">
                <ul>
                  <li> <img src="<?php echo base_url() ?>assets/images/checkicon1.png" alt=""> looking at its layout The point of using Lorem Ipsum </li>
                  <li> <img src="<?php echo base_url() ?>assets/images/checkicon1.png" alt=""> It is a long established fact that a reader will be distracted</li>
                  <li> <img src="<?php echo base_url() ?>assets/images/checkicon1.png" alt=""> looking at its layout The point of using Lorem Ipsum </li>
                  <li> <img src="<?php echo base_url() ?>assets/images/checkicon1.png" alt=""> looking at its layout The point of using Lorem Ipsum </li>
                  <li> <img src="<?php echo base_url() ?>assets/images/checkicon1.png" alt=""> looking at its layout The point of using Lorem Ipsum </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-md-7">
            <div class="about-image"> <img src="<?php echo base_url() ?>assets/images/aboutimg.png" alt="about image"> </div>
          </div>
        </div>
        
        
        <div class="face-plot-prices-wraper" data-aos="slide-up">
    <h3> Phase 1 - 7 Plots Price </h3>

    
    <div class="table-responsive">
    <table border="1" width="100%">
  <tr class="heading-plot-sale-table">
    <td colspan="7">Bahria Town Phase 1 Plot For Sale</td>
    </tr>
  <tr class="subheading-plot-sale-table">
    <td><strong>Plot Size</strong></td>
    <td><strong>Street No</strong></td>
    <td><strong>Plot No</strong>	</td>
    <td><strong>Price	</strong></td>
    <td><strong>Detail</strong></td>
    <td><strong>ID</strong></td>
    <td><strong>More Detail</strong></td>
  </tr>
  
  <tr>
    <td>20 Marla</td>
    <td>5</td>
    <td>117</td>
    <td>17,500,000</td>
    <td>St,5 Very Prime Location, Back To Boulevard, Walking Distance to Masjid & Commercial	</td>
    <td>2.11ms	</td>
    <td><a href="#">  More Info</a> </td>
  </tr>
  
  </table>

    
    </div>
    
    
    <div class="table-responsive">
    <table border="1" width="100%">
  <tr class="heading-plot-sale-table">
    <td colspan="7">Bahria Town Phase 1 Plot For Sale</td>
    </tr>
  <tr class="subheading-plot-sale-table">
    <td><strong>Plot Size</strong></td>
    <td><strong>Street No</strong></td>
    <td><strong>Plot No</strong>	</td>
    <td><strong>Price	</strong></td>
    <td><strong>Detail</strong></td>
    <td><strong>ID</strong></td>
    <td><strong>More Detail</strong></td>
  </tr>
  
  <tr>
    <td>20 Marla</td>
    <td>5</td>
    <td>117</td>
    <td>17,500,000</td>
    <td>St,5 Very Prime Location, Back To Boulevard, Walking Distance to Masjid & Commercial	</td>
    <td>2.11ms	</td>
    <td><a href="#">  More Info</a> </td>
  </tr>
  
  </table>

    
    </div>
    
    
    </div>
        
        
      </div>
    </div>
    
    <div class="aboutus-main-wraper">
      <div class="container">
        <div class="row">
          <div class="col-md-7 aos-init aos-animate" data-aos="slide-left">
            <div class="about-text-wraper">
              <h3> <?= $getsettingData['sell_buy_title'] ?> </h3>
              <p> <?= $getsettingData['sell_buy_description'] ?> </p>
              <div class="header-slider-buttons"> <a href="#" class="custom-site-button"> Contact us </a> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="maps-listingmain-wraper" data-aos="slide-up">
 <div class="container">
 <h3> Maps </h3>
 <ul class="row">
 
 <li class="col-md-4 col-sm-6 col-xs-12">
 <div class="maps-listing-wraper">
 <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url() ?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>
 
 
 
 </a>
 </div>
 </li>
 
 <li class="col-md-4 col-sm-6 col-xs-12">
 <div class="maps-listing-wraper">
 <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url() ?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>
 
 
 
 </a>
 </div>
 </li>
 
 <li class="col-md-4 col-sm-6 col-xs-12">
 <div class="maps-listing-wraper">
 <a href="#">
 <div class="maps-listing-image" style="background:url(<?php echo base_url() ?>assets/images/mapimg.jpg) no-repeat center">   </div>
 <h4> Bahria Town Islamabad </h4>
 
 
 
 </a>
 </div>
 </li>
 
 </ul>
 </div>
 </div>
    
    
    
    <div class="find-location-wraper">
      <div class="container">
        <h3 data-aos="slide-up" class="aos-init aos-animate"> <?= $getsettingData['free_consultation_title'] ?> </h3>
        <p data-aos="slide-up" class="aos-init aos-animate"> <?= $getsettingData['free_consultation_description'] ?> </p>
        <form class="row aos-init aos-animate" data-aos="slide-left">
          <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="form-group">
              <input type="email" class="form-control" placeholder="First Name">
            </div>
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="form-group">
              <input type="email" class="form-control" placeholder="Your Name">
            </div>
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="form-group">
              <input type="email" class="form-control" placeholder="Your Email">
            </div>
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="form-group">
              <input type="email" class="form-control" placeholder="Phone Number">
            </div>
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="form-group">
              <select class="form-control">
                <option>Area</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </select>
            </div>
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12">
            <select class="form-control">
              <option>Property Type</option>
              <option>Rental</option>
              <option>Buy</option>
            </select>
            <div class="clearfix"></div>
          </div>
          <div class="col-md-12 col-sm-12  col-xs-12">
            <div class="form-consult-button"> <a href="#" class="custom-site-button"> Consultation Now </a> </div>
          </div>
        </form>
      </div>
    </div>
    
  </div>
</div>
<!--//content ends--> 